import axios from "axios";
import { SET_CHARACTERS, SET_APP_LOADING } from "./actionTypes";

function setCharacters(payload) {
  return {
    type: SET_CHARACTERS,
    payload,
  };
}
function setAppLoading(payload) {
  return {
    type: SET_APP_LOADING,
    payload,
  };
}

export function getCharactersFromAPI() {
  return (dispatch) => {
    dispatch(setAppLoading(true));
    return axios
      .get("https://rickandmortyapi.com/api/character")
      .then((response) => {
        const {
          data: { results },
        } = response;

        dispatch(setCharacters(results));
        dispatch(setAppLoading(false));
      });
  };
}

export function clearCharacters() {
  return (dispatch) => {
    dispatch(setCharacters([]));
  };
}
