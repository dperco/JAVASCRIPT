export const SET_CHARACTERS = "characters/set";

export const SET_APP_LOADING = "app/loading/set";
