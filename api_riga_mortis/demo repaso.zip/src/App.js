import { Route } from "react-router-dom";

import Home from "./views/Home";
import Characters from "./views/Characters";
import CharacterDetail from "./views/CharacterDetail";
import { useSelector } from "react-redux";

function App() {
  const loading = useSelector((state) => state.app.loading);
  return (
    <div>
      {loading && (
        <div className="progress-bar">
          <div className="progress-bar-value"></div>
        </div>
      )}
      <Route path="/" exact component={Home} />
      <Route path="/characters" exact component={Characters} />
      <Route path="/characters/:id" exact component={CharacterDetail} />
    </div>
  );
}

export default App;
