import axios from "axios";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import style from "./CharacterDetail.module.css";

export default function CharacterDetail() {
  const { id } = useParams();
  const [state, setState] = useState();
  const [input, setInput] = useState({ text: "" });

  function handleChange(e) {
    setInput((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  }

  function handleSubmit(e) {
    e.preventDefault();
    console.log({ input });
    setInput({ text: "" });
  }

  function handleReset(e) {
    e.preventDefault();
    setInput({ text: "" });
  }

  useEffect(() => {
    axios
      .get(`https://rickandmortyapi.com/api/character/${id}`)
      .then((response) => setState(response.data));
  }, [id]);
  return (
    <div className={style.card}>
      {state && (
        <>
          <img
            style={{ height: "30rem", width: "30rem" }}
            alt=""
            src={state.image}
          ></img>
          <div className={style.field}>
            <label>Name:</label>
            <span>{state.name}</span>
          </div>
          <div className={style.field}>
            <label>Status:</label>
            <span>{state.status}</span>
          </div>
          <div className={style.field}>
            <label>Gender:</label>
            <span>{state.gender}</span>
          </div>
          <form onSubmit={handleSubmit} onReset={handleReset}>
            <input value={input.text} onChange={handleChange} name="text" />
            <input type="submit" value="Enviar" />
            <input type="reset" value="Resetear" />
          </form>
        </>
      )}
    </div>
  );
}
