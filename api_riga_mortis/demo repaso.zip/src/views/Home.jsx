import { Component } from "react";
import { Link } from "react-router-dom";

export default function Home() {
  return (
    <main>
      <h1>Hola 👋</h1>
      <section>
        <Link to="/characters">Ver lo personajes de Rick and Morty</Link>
      </section>
    </main>
  );
}

export class HomeClass extends Component {
  render() {
    return (
      <main>
        <h1>Hola 👋</h1>
        <section>
          <Link to="/characters">Ver lo personajes de Rick and Morty</Link>
        </section>
      </main>
    );
  }
}
