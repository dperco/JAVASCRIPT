import { Component, useEffect } from "react";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { connect } from "react-redux";
import Character from "../components/Character";
import { getCharactersFromAPI } from "../store/actions";

// Componente funcional

export default function Characters(props) {
  const {
    history: { push },
  } = props;

  const { characters } = useSelector((state) => state);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getCharactersFromAPI());
  }, [dispatch]);

  function handleNavigate(id) {
    push(`/characters/${id}`);
  }

  return (
    <main>
      {characters.map((character) => (
        <Character
          key={character.id}
          character={character}
          navigate={handleNavigate}
        />
      ))}
    </main>
  );
}

// Componente de clase

export const CharactersClass = connect(
  (state) => ({ characters: state.characters }),
  { getCharactersFromAPI }
)(
  class CharactersClass extends Component {
    constructor(props) {
      super(props);
      this.handleNavigate = this.handleNavigate.bind(this);
    }

    componentDidMount() {
      this.props.getCharactersFromAPI();
    }

    handleNavigate(id) {
      this.props.history.push(`/characters/${id}`);
    }

    // Alternativa que no requiere bindear
    // handleNavigate = (id) => {
    //   this.props.history.push(`/characters/${id}`);
    // };

    render() {
      return (
        <main>
          {this.props.characters.map((character) => (
            <Character
              key={character.id}
              character={character}
              navigate={this.handleNavigate}
            />
          ))}
        </main>
      );
    }
  }
);
