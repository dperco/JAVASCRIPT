import { Component } from "react";
import { MdOutlineNavigateNext } from "react-icons/md";

export default function Character(props) {
  const { character, navigate } = props;
  const { id, name, image } = character;
  return (
    <article
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        margin: "0.25rem 0",
        gap: "1rem",
        border: "solid 1px #f0f0f0",
        borderRadius: "0.5rem",
        overflow: "hidden",
        width: "100%",
        maxWidth: "20rem",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
        <img src={image} alt="" style={{ width: "5rem", height: "5rem" }} />
        <span>{name}</span>
      </div>
      <button onClick={() => navigate(id)} style={{ marginRight: "1rem" }}>
        <MdOutlineNavigateNext />
      </button>
    </article>
  );
}

export class CharacterClass extends Component {
  render() {
    const { character, navigate } = this.props;
    const { id, name, image } = character;
    return (
      <article
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          margin: "0.25rem 0",
          gap: "1rem",
          border: "solid 1px #f0f0f0",
          borderRadius: "0.5rem",
          overflow: "hidden",
          width: "100%",
          maxWidth: "20rem",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
          <img src={image} alt="" style={{ width: "5rem", height: "5rem" }} />
          <span>{name}</span>
        </div>
        <button onClick={() => navigate(id)} style={{ marginRight: "1rem" }}>
          <MdOutlineNavigateNext />
        </button>
      </article>
    );
  }
}
